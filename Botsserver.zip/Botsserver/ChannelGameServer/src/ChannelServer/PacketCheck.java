/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ChannelServer;

/**
 *
 * @author Marius
 */
public class PacketCheck {

}
